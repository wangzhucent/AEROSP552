#ifndef AUTOMATON_H
#define AUTOMATON_H
#include <string>
using namespace std;
bool automaton(string file, string input);
#endif