#ifndef HANOI_H
#define HANOI_H
void hanoi(int n);
void hanoi_helper(int n,int from, int to);
#endif