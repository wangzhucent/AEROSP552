#include <iostream>
#include "hanoi.h"
using namespace std;
int main()
{
	hanoi(4);
	return 1;
}