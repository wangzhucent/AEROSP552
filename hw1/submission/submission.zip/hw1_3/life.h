#ifndef LIFE_H
#define LIFE_H 
void life ();
#endif