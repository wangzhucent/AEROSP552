#ifndef FLY_H
#define FLY_H 
void fly(double latA, double longA, double latB, double longB);
#endif