#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
#include "life.h"
using namespace std;

//Try a life_cur.dat for updating the input data

int main()
{
	life();
	return 1;
}
